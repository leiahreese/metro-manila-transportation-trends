"""
app.py — Metro Manila Transportation Trend Dashboard
Step 3: Streamlit App
Run: streamlit run app/app.py
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os
import sqlite3

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Metro Manila Transportation Dashboard",
    page_icon="🚦",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROC_DIR = os.path.join(BASE_DIR, "data", "processed")
DB_PATH  = os.path.join(BASE_DIR, "data", "metro_manila.db")

# ── Color palette ─────────────────────────────────────────────────────────────
COLORS = {
    "primary":   "#E63946",
    "secondary": "#457B9D",
    "accent":    "#F4A261",
    "success":   "#2A9D8F",
    "bg":        "#0E1117",
    "card":      "#1E2130",
}

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .block-container { padding-top: 1.5rem; }
    .metric-card {
        background: #1E2130;
        border-radius: 12px;
        padding: 1.2rem 1.5rem;
        border-left: 4px solid;
        margin-bottom: 0.5rem;
    }
    .metric-card h3 { margin: 0; font-size: 0.85rem; color: #aaa; font-weight: 400; }
    .metric-card h1 { margin: 0.2rem 0 0; font-size: 2rem; font-weight: 700; }
    .metric-card p  { margin: 0.2rem 0 0; font-size: 0.8rem; color: #888; }
    .section-header {
        font-size: 1.1rem; font-weight: 600;
        border-bottom: 2px solid #E63946;
        padding-bottom: 0.3rem; margin-bottom: 1rem;
    }
</style>
""", unsafe_allow_html=True)

# ── Data loading ─────────────────────────────────────────────────────────────
@st.cache_data
def load(fname):
    return pd.read_csv(os.path.join(PROC_DIR, fname))

@st.cache_data
def load_db(query):
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df

incidents_monthly     = load("incidents_monthly.csv")
incidents_by_city     = load("incidents_by_city.csv")
incidents_by_type     = load("incidents_by_type.csv")
peak_heatmap          = load("peak_heatmap.csv")
peak_hourly           = load("peak_hourly.csv")
peak_locations        = load("peak_locations.csv")
ridership_annual      = load("ridership_annual.csv")
ridership_seasonality = load("ridership_seasonality.csv")
ridership_yoy         = load("ridership_yoy.csv")
ridership_recent      = load("ridership_recent.csv")

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🚦 Metro Manila")
    st.markdown("### Transportation Dashboard")
    st.markdown("---")
    st.markdown("**Data Sources**")
    st.markdown("- 🚗 MMDA Traffic Incidents (2018–2020)")
    st.markdown("- 🚇 MRT-3 Ridership (1999–2025)")
    st.markdown("---")
    st.markdown("**Built with**")
    st.markdown("Python · SQL · Streamlit · Plotly")
    st.markdown("---")
    st.caption("Lea Nikka F. Perez · PUP CpE")

# ── Title ─────────────────────────────────────────────────────────────────────
st.markdown("# 🚦 Metro Manila Transportation Trend Dashboard")
st.markdown("Analyzing traffic incidents and MRT-3 ridership patterns across Metro Manila.")
st.markdown("---")

# ══════════════════════════════════════════════════════════════════════════════
# TAB LAYOUT
# ══════════════════════════════════════════════════════════════════════════════
tab1, tab2, tab3 = st.tabs([
    "🚗  Traffic Volume & Incidents",
    "🕐  Peak Hour Analysis",
    "🚇  MRT-3 Ridership Trends",
])

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — TRAFFIC INCIDENTS
# ══════════════════════════════════════════════════════════════════════════════
with tab1:

    # KPI row
    total_inc = incidents_monthly["Total_Incidents"].sum()
    total_acc = incidents_monthly["Accidents"].sum()
    total_sta = incidents_monthly["Stalled"].sum()
    top_city  = incidents_by_city.iloc[0]["City"]

    k1, k2, k3, k4 = st.columns(4)
    k1.markdown(f"""<div class="metric-card" style="border-color:#E63946">
        <h3>Total Incidents</h3><h1 style="color:#E63946">{total_inc:,}</h1>
        <p>Aug 2018 – Dec 2020</p></div>""", unsafe_allow_html=True)
    k2.markdown(f"""<div class="metric-card" style="border-color:#F4A261">
        <h3>Vehicular Accidents</h3><h1 style="color:#F4A261">{total_acc:,}</h1>
        <p>{total_acc/total_inc*100:.1f}% of all incidents</p></div>""", unsafe_allow_html=True)
    k3.markdown(f"""<div class="metric-card" style="border-color:#457B9D">
        <h3>Stalled Vehicles</h3><h1 style="color:#457B9D">{total_sta:,}</h1>
        <p>{total_sta/total_inc*100:.1f}% of all incidents</p></div>""", unsafe_allow_html=True)
    k4.markdown(f"""<div class="metric-card" style="border-color:#2A9D8F">
        <h3>Most Affected City</h3><h1 style="color:#2A9D8F" style="font-size:1.4rem">{top_city}</h1>
        <p>{incidents_by_city.iloc[0]['Total_Incidents']:,} incidents recorded</p></div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Row 1: Monthly trend + Type donut
    c1, c2 = st.columns([2, 1])

    with c1:
        st.markdown('<div class="section-header">Monthly Incident Trend</div>', unsafe_allow_html=True)
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=incidents_monthly["YearMonth"], y=incidents_monthly["Accidents"],
            name="Accidents", fill="tozeroy",
            line=dict(color=COLORS["primary"], width=2),
            fillcolor="rgba(230,57,70,0.15)"
        ))
        fig.add_trace(go.Scatter(
            x=incidents_monthly["YearMonth"], y=incidents_monthly["Stalled"],
            name="Stalled Vehicles", fill="tozeroy",
            line=dict(color=COLORS["secondary"], width=2),
            fillcolor="rgba(69,123,157,0.15)"
        ))
        fig.update_layout(
            height=320, template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)", margin=dict(t=10, b=40, l=0, r=0),
            legend=dict(orientation="h", y=1.1), xaxis_title="Month", yaxis_title="Incidents"
        )
        st.plotly_chart(fig, use_container_width=True)

    with c2:
        st.markdown('<div class="section-header">Incident Breakdown</div>', unsafe_allow_html=True)
        fig2 = px.pie(
            incidents_by_type, values="Count", names="Incident_Category",
            hole=0.55,
            color_discrete_sequence=[COLORS["primary"], COLORS["secondary"], COLORS["accent"], COLORS["success"]]
        )
        fig2.update_layout(
            height=320, template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
            margin=dict(t=10, b=10, l=0, r=0),
            legend=dict(orientation="v", font=dict(size=11))
        )
        fig2.update_traces(textposition="inside", textinfo="percent+label")
        st.plotly_chart(fig2, use_container_width=True)

    # Row 2: City bar chart
    st.markdown('<div class="section-header">Incidents by City</div>', unsafe_allow_html=True)
    top10 = incidents_by_city.head(10)
    fig3 = px.bar(
        top10, x="City", y="Total_Incidents",
        color="Accidents",
        color_continuous_scale=["#457B9D", "#E63946"],
        labels={"Total_Incidents": "Total Incidents", "Accidents": "Accident Count"},
        text="Total_Incidents"
    )
    fig3.update_traces(textposition="outside")
    fig3.update_layout(
        height=360, template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", margin=dict(t=10, b=40, l=0, r=0),
        coloraxis_showscale=True
    )
    st.plotly_chart(fig3, use_container_width=True)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — PEAK HOURS
# ══════════════════════════════════════════════════════════════════════════════
with tab2:

    # KPIs
    peak_hr   = peak_hourly.loc[peak_hourly["Incidents"].idxmax(), "Hour"]
    peak_cnt  = peak_hourly["Incidents"].max()
    low_hr    = peak_hourly.loc[peak_hourly["Incidents"].idxmin(), "Hour"]

    def fmt_hour(h):
        if h == 0:   return "12 AM"
        if h < 12:   return f"{h} AM"
        if h == 12:  return "12 PM"
        return f"{h-12} PM"

    busiest_loc = peak_locations.iloc[0]["Location"]
    busiest_loc_city = peak_locations.iloc[0]["City"]

    k1, k2, k3, k4 = st.columns(4)
    k1.markdown(f"""<div class="metric-card" style="border-color:#E63946">
        <h3>Busiest Hour</h3><h1 style="color:#E63946">{fmt_hour(int(peak_hr))}</h1>
        <p>{peak_cnt:,} incidents at this hour</p></div>""", unsafe_allow_html=True)
    k2.markdown(f"""<div class="metric-card" style="border-color:#2A9D8F">
        <h3>Quietest Hour</h3><h1 style="color:#2A9D8F">{fmt_hour(int(low_hr))}</h1>
        <p>Fewest incidents recorded</p></div>""", unsafe_allow_html=True)
    k3.markdown(f"""<div class="metric-card" style="border-color:#F4A261">
        <h3>Busiest Location</h3><h1 style="color:#F4A261; font-size:1rem; padding-top:0.4rem">{busiest_loc}</h1>
        <p>{busiest_loc_city}</p></div>""", unsafe_allow_html=True)
    k4.markdown(f"""<div class="metric-card" style="border-color:#457B9D">
        <h3>Peak Period</h3><h1 style="color:#457B9D">AM Rush</h1>
        <p>7–9 AM highest volume window</p></div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Heatmap
    st.markdown('<div class="section-header">Incident Heatmap: Hour × Day of Week</div>', unsafe_allow_html=True)

    day_order = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    heat_pivot = peak_heatmap.pivot(index="DayOfWeek", columns="Hour", values="Incidents")
    heat_pivot = heat_pivot.reindex(day_order)

    fig4 = px.imshow(
        heat_pivot,
        color_continuous_scale=["#0E1117", "#457B9D", "#F4A261", "#E63946"],
        labels=dict(x="Hour of Day", y="Day of Week", color="Incidents"),
        aspect="auto"
    )
    hour_labels = {h: fmt_hour(h) for h in range(24)}
    fig4.update_xaxes(tickvals=list(range(24)), ticktext=[fmt_hour(h) for h in range(24)], tickangle=-45)
    fig4.update_layout(
        height=380, template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        margin=dict(t=10, b=60, l=0, r=0)
    )
    st.plotly_chart(fig4, use_container_width=True)

    # Hourly bar + top locations side by side
    c1, c2 = st.columns([3, 2])

    with c1:
        st.markdown('<div class="section-header">Incidents by Hour</div>', unsafe_allow_html=True)
        colors_bar = [COLORS["primary"] if h in [peak_hr] else COLORS["secondary"] for h in peak_hourly["Hour"]]
        fig5 = px.bar(
            peak_hourly, x="Hour", y="Incidents",
            color_discrete_sequence=[COLORS["secondary"]],
            labels={"Hour": "Hour of Day", "Incidents": "Total Incidents"},
        )
        # highlight rush hours
        for rush in [(6,9),(17,20)]:
            fig5.add_vrect(x0=rush[0]-0.5, x1=rush[1]-0.5, fillcolor="rgba(230,57,70,0.12)",
                           layer="below", line_width=0, annotation_text="Rush" if rush[0]==6 else "",
                           annotation_position="top left")
        fig5.update_xaxes(tickvals=list(range(0,24,2)), ticktext=[fmt_hour(h) for h in range(0,24,2)])
        fig5.update_layout(
            height=320, template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)", margin=dict(t=10, b=60, l=0, r=0)
        )
        st.plotly_chart(fig5, use_container_width=True)

    with c2:
        st.markdown('<div class="section-header">Top 10 Hotspot Locations</div>', unsafe_allow_html=True)
        fig6 = px.bar(
            peak_locations.head(10), x="Incidents", y="Location",
            orientation="h",
            color="Incidents",
            color_continuous_scale=["#457B9D", "#E63946"],
            labels={"Location": ""}
        )
        fig6.update_layout(
            height=320, template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)", margin=dict(t=10, b=10, l=0, r=0),
            yaxis=dict(autorange="reversed"), coloraxis_showscale=False
        )
        st.plotly_chart(fig6, use_container_width=True)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — MRT-3 RIDERSHIP
# ══════════════════════════════════════════════════════════════════════════════
with tab3:

    # Sidebar filter for year range
    year_range = st.slider(
        "Filter year range", 
        int(ridership_annual["Year"].min()),
        int(ridership_annual["Year"].max()),
        (2010, 2025)
    )

    ra_filtered = ridership_annual[
        ridership_annual["Year"].between(year_range[0], year_range[1])
    ]
    rr_filtered = ridership_recent[
        ridership_recent["Year"].between(max(year_range[0], 2019), year_range[1])
    ]

    # KPIs
    peak_year = ra_filtered.loc[ra_filtered["Annual_Total"].idxmax()]
    latest    = ra_filtered.iloc[-1]
    covid_drop = ridership_annual[ridership_annual["Year"]==2020]["Annual_Total"].values
    covid_drop_pct = ""
    if len(covid_drop):
        pre = ridership_annual[ridership_annual["Year"]==2019]["Annual_Total"].values
        if len(pre):
            covid_drop_pct = f"{(1 - covid_drop[0]/pre[0])*100:.0f}% drop vs 2019"

    k1, k2, k3, k4 = st.columns(4)
    k1.markdown(f"""<div class="metric-card" style="border-color:#E63946">
        <h3>Peak Year</h3><h1 style="color:#E63946">{int(peak_year['Year'])}</h1>
        <p>{peak_year['Annual_Total']/1e6:.1f}M total riders</p></div>""", unsafe_allow_html=True)
    k2.markdown(f"""<div class="metric-card" style="border-color:#2A9D8F">
        <h3>Latest Year Avg/Day</h3><h1 style="color:#2A9D8F">{latest['Avg_Daily']:,.0f}</h1>
        <p>Daily average ({int(latest['Year'])})</p></div>""", unsafe_allow_html=True)
    k3.markdown(f"""<div class="metric-card" style="border-color:#F4A261">
        <h3>COVID Impact</h3><h1 style="color:#F4A261">2020</h1>
        <p>{covid_drop_pct}</p></div>""", unsafe_allow_html=True)
    k4.markdown(f"""<div class="metric-card" style="border-color:#457B9D">
        <h3>Years of Data</h3><h1 style="color:#457B9D">26</h1>
        <p>1999 – 2025</p></div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Row 1: Annual total bar
    st.markdown('<div class="section-header">Annual MRT-3 Ridership</div>', unsafe_allow_html=True)

    yoy_f = ridership_yoy[ridership_yoy["Year"].between(year_range[0], year_range[1])]
    fig7 = make_subplots(specs=[[{"secondary_y": True}]])
    fig7.add_trace(go.Bar(
        x=ra_filtered["Year"], y=ra_filtered["Annual_Total"]/1e6,
        name="Annual Riders (M)", marker_color=COLORS["secondary"],
        opacity=0.85
    ), secondary_y=False)
    fig7.add_trace(go.Scatter(
        x=yoy_f["Year"], y=yoy_f["YoY_Growth_Pct"],
        name="YoY Growth %", mode="lines+markers",
        line=dict(color=COLORS["primary"], width=2),
        marker=dict(size=6)
    ), secondary_y=True)
    fig7.update_yaxes(title_text="Riders (Millions)", secondary_y=False)
    fig7.update_yaxes(title_text="YoY Growth %", secondary_y=True)
    fig7.add_hline(y=0, secondary_y=True, line_dash="dot", line_color="gray")
    fig7.update_layout(
        height=360, template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", margin=dict(t=10, b=40, l=0, r=0),
        legend=dict(orientation="h", y=1.08),
        xaxis_title="Year"
    )
    # Annotate COVID
    if year_range[0] <= 2020 <= year_range[1]:
        fig7.add_vrect(x0=2019.5, x1=2021.5, fillcolor="rgba(230,57,70,0.08)",
                       layer="below", line_width=0,
                       annotation_text="COVID-19", annotation_position="top left")
    st.plotly_chart(fig7, use_container_width=True)

    # Row 2: Monthly seasonality + recent trend
    c1, c2 = st.columns([1, 2])

    with c1:
        st.markdown('<div class="section-header">Monthly Seasonality (2010–2025)</div>', unsafe_allow_html=True)
        fig8 = px.bar(
            ridership_seasonality, x="Month_Name", y="Avg_Monthly",
            color="Avg_Monthly",
            color_continuous_scale=["#457B9D", "#E63946"],
            labels={"Month_Name": "Month", "Avg_Monthly": "Avg Monthly Riders"}
        )
        fig8.update_layout(
            height=320, template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)", margin=dict(t=10, b=60, l=0, r=0),
            xaxis_tickangle=-45, coloraxis_showscale=False
        )
        st.plotly_chart(fig8, use_container_width=True)

    with c2:
        st.markdown('<div class="section-header">Monthly Ridership 2019–Present (COVID Recovery)</div>', unsafe_allow_html=True)
        fig9 = px.line(
            rr_filtered, x="YearMonth", y="Total_Ridership",
            color="Year", color_discrete_sequence=px.colors.sequential.Plasma_r,
            labels={"YearMonth": "Month", "Total_Ridership": "Monthly Riders", "Year": "Year"},
            markers=False
        )
        if year_range[0] <= 2020 <= year_range[1]:
            fig9.add_vrect(x0="2020-03", x1="2021-06",
                           fillcolor="rgba(230,57,70,0.1)", layer="below", line_width=0,
                           annotation_text="Lockdown", annotation_position="top left")
        fig9.update_layout(
            height=320, template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)", margin=dict(t=10, b=60, l=0, r=0),
            xaxis_tickangle=-45
        )
        st.plotly_chart(fig9, use_container_width=True)

    # Raw data expander
    with st.expander("📄 View Raw Annual Data"):
        st.dataframe(
            ra_filtered[["Year","Annual_Total","Avg_Daily"]].assign(
                Annual_Total=lambda d: d["Annual_Total"].map("{:,.0f}".format),
                Avg_Daily=lambda d: d["Avg_Daily"].map("{:,.0f}".format),
            ).rename(columns={"Annual_Total":"Annual Riders","Avg_Daily":"Avg Daily Riders"}),
            use_container_width=True
        )
